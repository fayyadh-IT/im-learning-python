class animal:
    name = "" # property / attribute
    color = ""
    
    def makeSound(self, sound):  # method
        print(f"{self.name} is {sound}")

    def eat(self, food):
        print(f"{self.name} is eating {food}")

    def sleep(self):
        print(f"{self.name} is sleeping")

cat = animal()
cat.name = "bravo"
cat.makeSound("meowing")
cat.makeSound("meowing")
