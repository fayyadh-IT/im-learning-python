class animal:
    name = "" # property / attribute
    color = ""
  def makeSounde(self, sound):
    print("Animal is making sound")

  def eat(self, food):
    print("animal is esting", food)

  def sleep(self):
    print("animal is sleeping")

eat = animal()
cat.name = "mellow"
cat.color = "black"
cat.makeSounde("meow")
cat.eat("fish")
cat.sleep()
print(cat.name)

dog = animal()
