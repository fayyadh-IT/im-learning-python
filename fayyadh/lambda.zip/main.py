# def sayHello(name):
#    print("selamat datang",name)

sayHello = lambda name : print("selamat datang", name)

sayHello("jaka")

# def addition(num1, num2):
#    ressult = num1 + num2
#    print(result)

addition = lambda num1, num2 : print(num1+num2)

addition(10,12)

# lambda tanpa argumen
(lambda : print("selamat datang"))()
# lambda dengan argumen
(lambda fruit : print("saya suka", fruit))("nanas")
#lambda dangan default argumen
(lambda name="" : print("selamat datang", name))