from mathematic.square.area import square_area
from mathematic.square.perimeter import square_perimeter

from mathematic.triangle.area import triangle_area
from mathematic.triangle.perimeter import triangle_perimeter

from mathematic.circle.area import circle_area
from mathematic.circle.perimeter import circle_perimeter

square_area(5)
triangle_area(7, 6)
circle_area(5)

square_perimeter(7)
triangle_perimeter(5, 6, 7)
circle_perimeter(5)
