def circle_area(radius):
  pi = 22/7
  result = pi * radius * radius
  text = f"the area of circle is {result}"
  print(text)