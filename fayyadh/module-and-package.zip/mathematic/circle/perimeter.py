def circle_perimeter(side):
  pi = 22/7
  result = 2 * pi * side
  text = f"the perimeter of circle is {result}"
  print(text)