def square_area(side):
  result = side * side
  text = f"the area of square is {result}"
  print(text)
