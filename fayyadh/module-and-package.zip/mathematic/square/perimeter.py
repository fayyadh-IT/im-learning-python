def square_perimeter(side):
  result = 4 * side
  text = f"the perimeter of square is {result}"
  print(text)