def triangle_perimeter(side1, side2, side3):
  result = side1 + side2 + side3
  text = f"the perimeter of triangle is {result}"
  print(text)