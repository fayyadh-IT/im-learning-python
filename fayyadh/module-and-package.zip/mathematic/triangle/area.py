def triangle_area(base, height):
  result = (base * height) / 2
  text = f"the area of triangle is {result}"
  print(text)