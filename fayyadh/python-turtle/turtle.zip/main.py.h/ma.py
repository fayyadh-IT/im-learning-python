from turtle import *

getscreen()

bgcolor("")
speed(1)
forward(100)
left(90)


done()