class doctor1:
  reg_num = ""
  name = ""
  def __init__(self, name, reg_num):
    self.name = name
    self.reg_num = reg_num

  def getInfo(self):
    print("This doctor's name is", self.name, "and his reg number is", self.reg_num)

  def diagnose(self, patient):
    print("this doctor is diagnosing", patient)

  def treat(self, patient):
    print("this doctor is treating", patient)

my_doctor = doctor1("Dr. John", "12345")
my_doctor.getInfo()
my_doctor.diagnose("John")
my_doctor.treat("John")
