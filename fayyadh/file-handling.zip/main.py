# membuat file baru
# open('file_pertama.txt', 'x')

# untuk membaca file
#file = open('file_pertama.txt', 'r')
#print(file.read())

# membuat konten pada file
#file = open('file_pertama.txt', 'w')
#file.write("selamat datang")
#file.write("\n")
#file.write("nama saya fayyadh")
#file.close

# menambahkan konten
file = open('file_pertama.txt', 'a')
file.write("ini baris baru")
file.close()
